
public class Class_22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Один");
		System.out.println("Два");
		System.out.println("Три");
		System.out.println("Четыре");
		System.out.println("Пять");
		System.out.println("Шесть");
	}

}
