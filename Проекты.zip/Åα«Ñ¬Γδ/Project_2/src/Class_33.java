
public class Class_33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=22;
		
		System.out.println("Юлий");
		System.out.println("22");
		System.out.println("Юлий "+age);
	}

}
